# 4. Linear Regression

[Back to experiments](../README.md)

[Python source](11259A220_linear_regression.py) | [Dataset](11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_data.csv) | [Text output](11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_output.txt)

## Code

```python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load dataset
data = pd.read_csv("11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_data.csv")

# Input feature
X = data[['Hours_Studied']]

# Target variable
y = data['Marks']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Create Linear Regression model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Predict values
y_pred = model.predict(X_test)

# Evaluate performance
print("Mean Squared Error:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

# Display predictions
print("\nPredicted Marks:")
print(y_pred)

# Graph
plt.scatter(X_test, y_test, label="Actual Data")
plt.plot(X_test, y_pred, label="Regression Line")
plt.xlabel("Hours Studied")
plt.ylabel("Marks")
plt.title("Linear Regression")
plt.legend()
plt.show()
```

## Output

```text
Mean Squared Error: 6.750000000000021
R2 Score: 0.879866518353726

Predicted Marks:
[45. 35. 55. 55.]
```

## Graphs

![Linear Regression - 11259A220_linear_regression.png](11259A220_linear_regression.png)


## Run

From this experiment folder, run: `python 11259A220_linear_regression.py`.

