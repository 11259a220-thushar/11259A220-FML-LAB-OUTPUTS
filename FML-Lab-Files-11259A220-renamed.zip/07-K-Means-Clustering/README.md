# 7. K Means Clustering

[Back to experiments](../README.md)

[Python source](11259A220_kmeans_clustering.py) | [Dataset](11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_data.csv) | [Text output](11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_output.txt)

## Code

```python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
# Load dataset
data = pd.read_csv("11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_11259A220_data.csv")
# Select features
X = data[['Hours_Studied','Marks']]
# Create K-Means model
kmeans = KMeans(n_clusters=3, random_state=42)
# Fit the model
kmeans.fit(X)
# Predict cluster labels
clusters = kmeans.labels_
# Add cluster column to dataset
data['Cluster'] = clusters
# Display clustered data
print(data)
# Plot clusters
plt.scatter(X['Hours_Studied'], X['Marks'], c=clusters)
# Plot centroids
plt.scatter(
kmeans.cluster_centers_[:, 0],
kmeans.cluster_centers_[:, 1],
marker='X',
s=200,
label='Centroids'
)
plt.xlabel("Hours Studied")
plt.ylabel("Marks")
plt.title("K-Means Clustering")
plt.legend()
plt.show()
```

## Output

```text
    StudentID  Hours_Studied  Attendance  Assignments  Marks Result  Cluster
0           1              2          75            3     45   Fail        0
1           2              3          80            4     52   Pass        1
2           3              4          85            5     60   Pass        1
3           4              1          65            2     35   Fail        0
4           5              5          90            5     75   Pass        2
5           6              6          95            5     82   Pass        2
6           7              2          70            3     48   Fail        0
7           8              7          98            5     90   Pass        2
8           9              3          78            4     55   Pass        1
9          10              4          88            4     68   Pass        1
10         11              1          60            2     30   Fail        0
11         12              5          92            5     80   Pass        2
12         13              6          96            5     85   Pass        2
13         14              2          72            3     46   Fail        0
14         15              4          84            4     65   Pass        1
15         16              3          79            4     58   Pass        1
16         17              7          99            5     95   Pass        2
17         18              1          68            2     38   Fail        0
18         19              5          91            5     78   Pass        2
19         20              6          97            5     88   Pass        2
```

## Graphs

![K-Means Clustering - 11259A220_kmeans.png](11259A220_kmeans.png)


## Run

From this experiment folder, run: `python 11259A220_kmeans_clustering.py`.

